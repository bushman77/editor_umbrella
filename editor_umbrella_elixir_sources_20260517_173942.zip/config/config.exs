# This file is responsible for configuring your umbrella
# and **all applications** and their dependencies with the
# help of the Config module.
#
# Note that all applications in your umbrella share the
# same configuration and dependencies, which is why they
# all use the same configuration file. If you want different
# configurations or dependencies per app, it is best to
# move said applications out of the umbrella.
import Config

# Configure Mix tasks and generators
config :editor,
  ecto_repos: [Editor.Repo]

# Configures the mailer
#
# By default it uses the "Local" adapter which stores the emails
# locally. You can see the emails in your browser, at "/dev/mailbox".
#
# For production it's recommended to configure a different adapter
# at the `config/runtime.exs`.
config :editor, Editor.Mailer, adapter: Swoosh.Adapters.Local

config :editor_web,
  ecto_repos: [Editor.Repo],
  generators: [context_app: :editor]

config :llm,
  enabled: true,
  model: "~/models/Qwen2.5-Coder-7B-Instruct-Q5_K_M.gguf",
  llama_dir: "~/llama.cpp",
  llama_server_path: "build/bin/llama-server",
  host: "127.0.0.1",
  port: 8000,
  flash_attention: "on",
  gpu_layers: "auto",
  parallel_slots: 1,
  context_size: 32_768,
  max_tokens: 8_192,
  batch_size: 2_048,
  micro_batch_size: 512,
  startup_wait_ms: 30_000,
  poll_interval_ms: 500,
  tcp_connect_timeout_ms: 1_000,
  client_receive_timeout: :infinity,
  client_connect_timeout_ms: 5_000,
  opencode_acp_enabled: true,
  opencode_cmd: "opencode",
  opencode_args: ["acp"],
  opencode_cwd: File.cwd!()

#    "~/models/qwen3-coder-next/Qwen3-Coder-Next-Q5_K_M/Qwen3-Coder-Next-Q5_K_M-00001-of-00004.gguf"
# Configures the endpoint
config :editor_web, EditorWeb.Endpoint,
  url: [host: "localhost"],
  adapter: Bandit.PhoenixAdapter,
  render_errors: [
    formats: [html: EditorWeb.ErrorHTML, json: EditorWeb.ErrorJSON],
    layout: false
  ],
  pubsub_server: Editor.PubSub,
  live_view: [signing_salt: "qQ6cTzqn"]

# Configure esbuild (the version is required)
config :esbuild,
  version: "0.25.4",
  editor_web: [
    args:
      ~w(js/app.js --bundle --target=es2022 --outdir=../priv/static/assets/js --external:/fonts/* --external:/images/* --alias:@=.),
    cd: Path.expand("../apps/editor_web/assets", __DIR__),
    env: %{"NODE_PATH" => [Path.expand("../deps", __DIR__), Mix.Project.build_path()]}
  ]

# Configure tailwind (the version is required)
config :tailwind,
  version: "4.1.7",
  editor_web: [
    args: ~w(
      --input=assets/css/app.css
      --output=priv/static/assets/css/app.css
    ),
    cd: Path.expand("../apps/editor_web", __DIR__)
  ]

# Configures Elixir's Logger
config :logger, :default_formatter,
  format: "$time $metadata[$level] $message\n",
  metadata: [:request_id]

# Use Jason for JSON parsing in Phoenix
config :phoenix, :json_library, Jason

# Import environment specific config. This must remain at the bottom
# of this file so it overrides the configuration defined above.
import_config "#{config_env()}.exs"
